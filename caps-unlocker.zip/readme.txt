CapsUnlocker v1.1
==================================================================
Copyright � 2013 Igor Tolmachev, IT Samples.
http://www.itsamples.com
All Rights Reserved.
==================================================================

CapsUnlocker allows you to unlock the Caps Lock state after a 
period of no keyboard activity and to prevent the accidental
turning on of Caps Lock with an override option (Caps Lock can
be switched on and off by holding down the Shift key).

If you encounter a problem while running this utility,
please record all the information and send it to:
support@itsamples.com